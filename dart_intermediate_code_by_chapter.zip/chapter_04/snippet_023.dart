void main() {
  var (sum, product) = calculate(3, 4);
  print('Sum: $sum, Product: $product');
}
