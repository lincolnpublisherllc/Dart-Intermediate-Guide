void main() {
  var result = calculate(3, 4);
  print('Sum: ${result.sum}, Product: ${result.product}');
}
