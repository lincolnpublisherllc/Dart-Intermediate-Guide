var student = {
  'name': 'Chika',
  'grades': {'math': 90, 'science': 85}
};
print(student['grades']?['math']); // 90
