bool operator ==(Object other) =>
      other is Person && other.name == name && other.age == age;
