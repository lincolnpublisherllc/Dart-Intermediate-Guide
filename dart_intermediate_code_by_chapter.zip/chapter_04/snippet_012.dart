class Node {
  int value;
  Node? left;
  Node? right;
