Result(this.sum, this.product);
}
