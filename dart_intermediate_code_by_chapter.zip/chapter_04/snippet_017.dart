traverse(root); // Output: 5, 7, 10, 15
}
