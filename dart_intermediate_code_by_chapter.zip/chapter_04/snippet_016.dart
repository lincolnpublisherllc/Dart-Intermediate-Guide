void main() {
  var root = Node(10);
  insert(root, 5);
  insert(root, 15);
  insert(root, 7);
