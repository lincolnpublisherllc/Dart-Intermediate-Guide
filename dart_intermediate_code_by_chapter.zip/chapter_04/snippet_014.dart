void insert(Node root, int newValue) {
  if (newValue < root.value) {
    if (root.left == null) {
      root.left = Node(newValue);
    } else {
      insert(root.left!, newValue);
    }
  } else {
    if (root.right == null) {
      root.right = Node(newValue);
    } else {
      insert(root.right!, newValue);
    }
  }
}
