Result calculate(int a, int b) {
  return Result(a + b, a * b);
}
