void traverse(Node? node) {
  if (node == null) return;
  traverse(node.left);
  print(node.value);
  traverse(node.right);
}
