int get hashCode => name.hashCode ^ age.hashCode;
}
