class Result {
  final int sum;
  final int product;
