void main() {
  var scores = {'John': 80};
  scores.putIfAbsent('Ada', () => 95);
  print(scores); // {John: 80, Ada: 95}
}
