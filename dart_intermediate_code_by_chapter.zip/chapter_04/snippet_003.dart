class Person {
  final String name;
  final int age;
