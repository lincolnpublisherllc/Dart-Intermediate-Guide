scores.forEach((key, value) {
  print('$key scored $value');
});
