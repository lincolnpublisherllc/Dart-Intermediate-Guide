void main() {
  var people = <Person>{};
  people.add(Person('Ada', 25));
  people.add(Person('Ada', 25)); // Duplicate ignored
  print(people.length); // 1
}
