(int, int) calculate(int a, int b) {
  return (a + b, a * b);
}
