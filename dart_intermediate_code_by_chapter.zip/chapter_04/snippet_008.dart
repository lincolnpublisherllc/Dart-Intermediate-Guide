Maps (also known as dictionaries) store key-value pairs. You’ve seen the basics; let’s extend that.
