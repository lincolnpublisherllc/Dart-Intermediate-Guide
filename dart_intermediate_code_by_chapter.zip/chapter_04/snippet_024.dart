Implement a binary tree that stores strings instead of integers. Insert three values and print them in order.
