Avoid using any, which can lead to unpredictable builds.
