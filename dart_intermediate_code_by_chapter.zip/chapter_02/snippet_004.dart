pubspec.yaml → The project’s manifest file: defines dependencies, metadata, and environment constraints.
