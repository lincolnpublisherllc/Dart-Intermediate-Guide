Open bin/weather_cli.dart and import the packages.
