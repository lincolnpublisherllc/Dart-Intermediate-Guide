bin/ → Holds the entry point file (like main.dart). Think of this as your “executable” folder.
lib/ → Where your reusable code modules go. Anything you want to export lives here.
