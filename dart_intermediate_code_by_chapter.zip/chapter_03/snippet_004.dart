void confirmOrder(String product) {
  print('Order processed: $product');
}
