class User {
  final String name;
  final String email;
