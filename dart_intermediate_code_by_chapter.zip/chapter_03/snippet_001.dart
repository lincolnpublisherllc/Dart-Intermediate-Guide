void processOrder(String product, int quantity, double price) {
  double total = quantity * price;
  print('Total: $total');
  if (quantity > 10) {
    print('Discount applied!');
  }
  print('Order processed: $product');
}
