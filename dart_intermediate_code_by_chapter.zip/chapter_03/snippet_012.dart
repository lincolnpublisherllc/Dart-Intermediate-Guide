class AuthService {
  bool login(User user, String password) {
    // Stubbed login logic
    return user.email == 'test@example.com' && password == '1234';
  }
}
