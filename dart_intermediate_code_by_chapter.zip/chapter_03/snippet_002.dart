double calculateTotal(int quantity, double price) => quantity * price;
