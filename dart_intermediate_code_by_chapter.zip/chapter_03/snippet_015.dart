if (auth.login(user, '1234')) {
    print('Login successful');
  } else {
    print('Login failed');
  }
}
