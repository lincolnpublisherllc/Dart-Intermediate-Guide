int square(int x) => x * x;
int triple(int x) => x * 3;
