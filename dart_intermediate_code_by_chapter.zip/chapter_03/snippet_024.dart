void main() {
  print(add(10, 5));       // 15
  print(divide(20, 4));    // 5
}
