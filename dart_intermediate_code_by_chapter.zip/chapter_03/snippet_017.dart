bool isValidEmail(String email) => email.contains('@');
bool isValidPassword(String password) => password.length >= 6;
