void displayInfo() {
    print('Name: $name, Email: $email');
  }
}
