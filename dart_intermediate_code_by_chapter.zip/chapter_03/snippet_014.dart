void main() {
  var user = User('Ada', 'test@example.com');
  var auth = AuthService();
