To avoid cluttered imports, Dart allows you to group files with library and export.
