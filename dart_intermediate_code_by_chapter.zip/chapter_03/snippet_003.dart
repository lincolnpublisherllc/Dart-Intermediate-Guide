void applyDiscount(int quantity) {
  if (quantity > 10) {
    print('Discount applied!');
  }
}
