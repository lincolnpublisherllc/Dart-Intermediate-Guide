void main() {
  applyToNumbers([1, 2, 3], square);
  applyToNumbers([1, 2, 3], triple);
}
