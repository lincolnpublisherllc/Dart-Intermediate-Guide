Create a class ShoppingCart with a method addItem() and a method totalPrice().
