void main() {
  group('Math operations', () {
    test('multiplication works', () {
      expect(multiply(2, 3), 6);
    });
