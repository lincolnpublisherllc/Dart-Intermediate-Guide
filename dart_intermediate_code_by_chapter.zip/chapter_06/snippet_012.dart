test('division by zero throws error', () {
    expect(() => divide(10, 0), throwsA(isA<ArgumentError>()));
  });
}
