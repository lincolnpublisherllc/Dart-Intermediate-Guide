void main() {
  test('addition works', () {
    expect(add(2, 3), equals(5));
  });
