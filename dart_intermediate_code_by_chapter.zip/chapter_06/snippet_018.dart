void main() {
  log('Application started', level: 800); // Info
  log('A warning occurred', level: 900);  // Warning
}
