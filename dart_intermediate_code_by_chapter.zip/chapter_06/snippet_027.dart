Debugging asynchronous code (Future and async/await).
