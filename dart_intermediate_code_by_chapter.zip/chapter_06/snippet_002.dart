void main() {
  withdraw(100, 50);
}
