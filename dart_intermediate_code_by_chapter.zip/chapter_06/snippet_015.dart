test('subtraction works', () {
      expect(subtract(10, 4), 6);
    });
  });
}
