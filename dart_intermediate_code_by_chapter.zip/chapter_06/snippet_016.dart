1. Print Debugging
The simplest form — sprinkle print() statements.
print('Value of x: $x');
