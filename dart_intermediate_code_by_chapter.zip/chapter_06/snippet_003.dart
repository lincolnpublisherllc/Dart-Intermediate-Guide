void main() {
  try {
    withdraw(100, 50);
  } catch (e) {
    print('Error: $e');
  }
}
