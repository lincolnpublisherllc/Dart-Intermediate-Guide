void withdraw(int amount, int balance) {
  if (amount > balance) {
    throw Exception('Insufficient funds');
  }
  print('Withdrawal successful');
}
