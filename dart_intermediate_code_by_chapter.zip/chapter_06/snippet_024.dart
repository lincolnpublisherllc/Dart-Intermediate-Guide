void main() {
  test('deposit increases balance', () {
    var account = BankAccount(100);
    account.deposit(50);
    expect(account.balance, 150);
  });
