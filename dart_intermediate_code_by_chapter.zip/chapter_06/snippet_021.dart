void deposit(int amount) {
    balance += amount;
  }
