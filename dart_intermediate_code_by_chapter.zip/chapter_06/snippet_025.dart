test('withdraw throws on insufficient funds', () {
    var account = BankAccount(50);
    expect(() => account.withdraw(100), throwsException);
  });
}
