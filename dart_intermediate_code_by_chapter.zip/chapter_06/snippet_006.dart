void withdraw(int amount, int balance) {
  if (amount > balance) {
    throw InsufficientFundsException('Tried to withdraw $amount, balance is $balance');
  }
}
