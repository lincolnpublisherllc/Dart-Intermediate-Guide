String toString() => 'InsufficientFundsException: $message';
}
