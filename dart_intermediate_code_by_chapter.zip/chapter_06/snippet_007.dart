void main() {
  try {
    withdraw(200, 100);
  } on InsufficientFundsException catch (e) {
    print('Custom error: $e');
  }
}
