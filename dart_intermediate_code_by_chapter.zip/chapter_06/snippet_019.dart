class BankAccount {
  int balance;
