void main() {
  try {
    print('Trying risky operation...');
    throw Exception('Something went wrong');
  } catch (e) {
    print('Caught error: $e');
  } finally {
    print('Always runs: closing files or connections.');
  }
}
