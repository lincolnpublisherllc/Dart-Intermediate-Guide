final regex = RegExp(r'^[a-z]+$');
for (int i = 0; i < 1000; i++) {
  regex.hasMatch('dart');
}
