var numbers = List.generate(1000000, (i) => i);  
var evens = numbers.where((n) => n.isEven); // Lazy iterable
