await for (var line in file.openRead()
      .transform(SystemEncoding().decoder)
      .transform(const LineSplitter())) {
    for (var word in line.split(' ')) {
      counts[word] = (counts[word] ?? 0) + 1;
    }
  }
