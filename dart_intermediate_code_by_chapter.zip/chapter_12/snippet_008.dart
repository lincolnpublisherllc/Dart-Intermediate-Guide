var sum = numbers.reduce((a, b) => a + b);
