Avoid premature optimization — focus only where bottlenecks exist.
