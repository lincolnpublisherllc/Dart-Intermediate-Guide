Timeline: visualizes async tasks and isolates.
