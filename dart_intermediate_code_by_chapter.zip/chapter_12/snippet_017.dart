for (var w in words) {
  counts[w] = (counts[w] ?? 0) + 1;
}
print('Unique words: ${counts.length}');
