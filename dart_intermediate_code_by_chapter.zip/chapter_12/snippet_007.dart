int sum = 0;
for (var n in numbers) {
  sum += n;
}
