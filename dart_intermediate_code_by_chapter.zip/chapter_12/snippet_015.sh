dart run --observe bin/main.dart
