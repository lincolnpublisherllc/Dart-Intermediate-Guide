Avoid Unnecessary Object Creation
