for (int i = 0; i < 1000; i++) {
  var regex = RegExp(r'^[a-z]+$');
  regex.hasMatch('dart');
}
