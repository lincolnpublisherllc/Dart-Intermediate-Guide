String text = File('bigfile.txt').readAsStringSync();
var words = text.split(' ');
var counts = <String, int>{};
