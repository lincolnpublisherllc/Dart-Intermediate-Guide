void main() async {
  var counts = <String, int>{};
  var file = File('bigfile.txt');
