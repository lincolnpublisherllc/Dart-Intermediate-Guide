var buffer = StringBuffer();
for (int i = 0; i < 1000; i++) {
  buffer.write(i);
}
var result = buffer.toString();
