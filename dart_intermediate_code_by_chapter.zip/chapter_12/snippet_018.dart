Optimized Implementation (Streaming)
import 'dart:io';
