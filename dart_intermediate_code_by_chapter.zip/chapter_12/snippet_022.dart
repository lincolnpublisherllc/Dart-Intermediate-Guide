Async performance tuning (Future.wait, isolates).
