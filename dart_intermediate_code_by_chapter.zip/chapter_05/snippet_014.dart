void main() {
  var file = File('people.csv').readAsStringSync();
  List<List<dynamic>> rows = const CsvToListConverter().convert(file);
