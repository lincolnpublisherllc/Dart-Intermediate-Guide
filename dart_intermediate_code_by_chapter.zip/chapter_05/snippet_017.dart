void main() {
  var file = File('app.log');
  var timestamp = DateTime.now().toIso8601String();
