void main() {
  var file = File('output.txt');
  file.writeAsStringSync('Hello, Dart file!');
  print('File written.');
}
