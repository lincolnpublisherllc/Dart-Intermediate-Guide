void main() {
  var file = File('notes.txt');
  String contents = file.readAsStringSync();
  print(contents);
}
