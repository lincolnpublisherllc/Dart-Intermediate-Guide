Example JSON file (data.json):
{
  "name": "Ada",
  "age": 25,
  "skills": ["Dart", "Flutter", "Firebase"]
}
