Write a program that asks for your name and age, then saves it as JSON in user.json.
