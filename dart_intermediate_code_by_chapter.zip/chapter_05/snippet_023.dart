Asynchronous file I/O (non-blocking reads/writes with await).
