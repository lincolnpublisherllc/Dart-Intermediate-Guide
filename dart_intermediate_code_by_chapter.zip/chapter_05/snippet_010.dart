void main() {
  var file = File('data.json');
  String contents = file.readAsStringSync();
  var data = jsonDecode(contents);
