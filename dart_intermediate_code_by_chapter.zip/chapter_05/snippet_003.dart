void main() {
  var file = File('notes.txt');
  List<String> lines = file.readAsLinesSync();
  for (var line in lines) {
    print('Line: $line');
  }
}
