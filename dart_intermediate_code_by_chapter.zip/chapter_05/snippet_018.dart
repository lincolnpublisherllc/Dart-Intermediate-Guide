file.writeAsStringSync(
