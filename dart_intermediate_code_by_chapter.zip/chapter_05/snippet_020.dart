print('Log written.');
}
