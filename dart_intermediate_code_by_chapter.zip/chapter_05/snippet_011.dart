print('Name: ${data['name']}');
  print('Age: ${data['age']}');
  print('Skills: ${data['skills']}');
}
