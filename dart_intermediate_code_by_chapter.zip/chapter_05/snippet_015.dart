for (var row in rows) {
    print(row);
  }
}
