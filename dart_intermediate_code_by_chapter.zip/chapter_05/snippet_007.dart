if (file.existsSync()) {
  print('File found.');
} else {
  print('File not found.');
}
