Using the csv package, read a CSV file of student names and grades. Print the average grade.
