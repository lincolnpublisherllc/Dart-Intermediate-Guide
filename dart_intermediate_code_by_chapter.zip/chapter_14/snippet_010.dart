Future.wait simplified running multiple async queries at once.
