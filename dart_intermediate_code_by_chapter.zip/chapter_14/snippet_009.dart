await for (HttpRequest request in server) {
    if (request.uri.path == '/ws') {
      var socket = await WebSocketTransformer.upgrade(request);
      socket.listen((message) {
        print('Received: $message');
        socket.add('Echo: $message');
      });
    }
  }
}
