Streams update balances in real time.
