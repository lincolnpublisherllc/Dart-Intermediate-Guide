Dart’s async/await made API calls simple and safe.
Using immutable models (with const constructors) reduced bugs.
Isolates kept encryption tasks off the UI thread, avoiding freezes.
