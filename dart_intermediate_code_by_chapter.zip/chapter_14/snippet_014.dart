Streams were perfect for continuous sensor feeds.
