Code Snapshot: Sensor Stream
Stream<int> sensorStream() async* {
  for (var i = 0; i < 5; i++) {
    await Future.delayed(Duration(seconds: 1));
    yield i * 10; // Simulated sensor value
  }
}
