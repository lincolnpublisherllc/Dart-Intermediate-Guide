A simple command-line interface to interact with the API (dart run cli.dart add "Buy milk").
