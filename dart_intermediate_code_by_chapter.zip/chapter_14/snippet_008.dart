void main() async {
  var server = await HttpServer.bind('localhost', 8080);
  print('WebSocket server running on ws://localhost:8080');
