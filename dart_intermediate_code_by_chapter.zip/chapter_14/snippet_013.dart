void main() async {
  await for (var value in sensorStream()) {
    print('Sensor reading: $value');
  }
}
