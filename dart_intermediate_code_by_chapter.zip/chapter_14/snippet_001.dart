Isolates → Handle encryption and background tasks without freezing the UI.
