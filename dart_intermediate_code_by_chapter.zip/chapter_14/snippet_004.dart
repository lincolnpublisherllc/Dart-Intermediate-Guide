Transaction(this.id, this.amount, this.date, this.type);
