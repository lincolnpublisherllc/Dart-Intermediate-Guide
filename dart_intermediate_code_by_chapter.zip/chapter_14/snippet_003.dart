class Transaction {
  final String id;
  final double amount;
  final DateTime date;
  final String type; // debit or credit
