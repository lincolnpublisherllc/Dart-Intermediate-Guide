factory Transaction.fromJson(Map<String, dynamic> json) {
    return Transaction(
      json['id'],
      json['amount'],
      DateTime.parse(json['date']),
      json['type'],
    );
  }
}
This model integrates seamlessly with json_serializable for API sync.
