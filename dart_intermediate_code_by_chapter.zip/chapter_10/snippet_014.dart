router.get('/', (Request req) {
    return Response.ok('Welcome to Blog API');
  });
