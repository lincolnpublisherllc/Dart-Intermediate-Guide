void main() async {
  final handler = Pipeline()
      .addMiddleware(logRequests())
      .addHandler(blogApi());
