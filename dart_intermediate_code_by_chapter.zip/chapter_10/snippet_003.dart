Parses arguments (e.g., dart run todo add "Buy milk")
