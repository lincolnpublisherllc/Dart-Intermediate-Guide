Create the Post model with json_serializable.
