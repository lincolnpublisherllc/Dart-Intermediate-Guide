Handle asynchronous I/O without blocking.
