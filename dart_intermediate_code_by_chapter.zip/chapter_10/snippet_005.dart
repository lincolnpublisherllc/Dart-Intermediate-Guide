pubspec.yaml → dependencies
