Uses classes, collections, and async timers
