dart run bin/server.dart
