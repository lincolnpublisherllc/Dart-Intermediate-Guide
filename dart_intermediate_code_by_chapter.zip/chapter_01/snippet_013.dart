void main() {
  print(square(4));                    // 16
  print(greet(name: 'Chika'));         // Hello Mr./Ms. Chika
  print(greet(name: 'Amina', title: 'Dr.')); // Hello Dr. Amina
}
