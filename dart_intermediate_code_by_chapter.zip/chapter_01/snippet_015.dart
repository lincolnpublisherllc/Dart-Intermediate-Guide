void main() {
  final scores = {'Ada': 85, 'John': 92, 'Chika': 78};
