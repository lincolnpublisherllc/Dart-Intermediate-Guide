Create a map of city names to populations. Print only the cities with population greater than 1 million.
