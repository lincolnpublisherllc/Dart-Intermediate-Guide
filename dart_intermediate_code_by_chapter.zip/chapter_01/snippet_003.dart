Return Type: void means nothing is returned. Later, we’ll see that main() can also return Future<void> in async contexts.
Braces { }: Group statements together; nesting is common.
