int a = 10, b = 3;
print(a ~/ b); // integer division
print(a % b);  // remainder
