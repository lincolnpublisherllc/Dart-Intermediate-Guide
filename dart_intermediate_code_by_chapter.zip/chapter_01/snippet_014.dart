final studentAges = {'Ada': 20, 'John': 22, 'Chika': 19};
print(studentAges['Ada']); // 20
