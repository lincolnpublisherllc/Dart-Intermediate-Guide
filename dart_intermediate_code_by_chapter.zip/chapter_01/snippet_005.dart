When documenting intent: int vs double vs num carry different expectations.
