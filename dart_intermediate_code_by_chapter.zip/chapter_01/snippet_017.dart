final average = total / scores.length;
  print('Average score: $average');
}
