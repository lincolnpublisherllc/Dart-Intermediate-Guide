final numbers = [1, 2, 3, 4, 5];
numbers.where((n) => n.isEven).forEach(print);
