if ((a > 5 && b < 5) || a == 10) {
  print('Condition met');
}
