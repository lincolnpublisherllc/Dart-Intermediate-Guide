var city = 'Lagos';        // Inferred as String
String country = 'Nigeria'; // Explicit type
