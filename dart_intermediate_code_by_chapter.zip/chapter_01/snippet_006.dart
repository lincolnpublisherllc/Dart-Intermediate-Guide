final timestamp = DateTime.now();  // runtime known
const pi = 3.14159;                // compile-time known
