int square(int x) => x * x;
