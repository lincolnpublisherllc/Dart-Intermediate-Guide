int total = 0;
  scores.forEach((_, score) => total += score);
