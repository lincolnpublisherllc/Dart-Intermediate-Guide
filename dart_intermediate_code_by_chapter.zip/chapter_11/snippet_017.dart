void main() async {
  var dio = Dio();
  dio.options.baseUrl = 'https://api.open-meteo.com/v1/';
