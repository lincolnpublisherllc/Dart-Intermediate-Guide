await connection.query(
  'INSERT INTO users(name, age) VALUES (@name, @age)',
  substitutionValues: {'name': 'Ada', 'age': 25},
);
