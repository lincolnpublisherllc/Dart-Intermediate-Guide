var results = await connection.query('SELECT * FROM users');
for (final row in results) {
  print('User: ${row[1]}, Age: ${row[2]}');
}
