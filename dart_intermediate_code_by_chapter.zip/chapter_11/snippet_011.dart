void main() async {
  var db = Db('mongodb://localhost:27017/mydb');
  await db.open();
