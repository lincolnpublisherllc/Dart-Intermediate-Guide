await connection.query('''
  CREATE TABLE users (
