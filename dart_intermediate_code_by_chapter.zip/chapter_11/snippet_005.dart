await connection.open();
  print('Connected to Postgres!');
  await connection.close();
}
