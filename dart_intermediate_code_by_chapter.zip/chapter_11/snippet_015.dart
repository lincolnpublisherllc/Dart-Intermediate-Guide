[{_id: ObjectId(...), name: John, age: 30}]
