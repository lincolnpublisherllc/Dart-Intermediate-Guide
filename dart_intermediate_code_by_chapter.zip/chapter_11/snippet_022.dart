Parse the JSON response into a Dart class Price.
