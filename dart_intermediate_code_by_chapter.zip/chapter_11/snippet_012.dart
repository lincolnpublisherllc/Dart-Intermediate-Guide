var collection = db.collection('users');
  await collection.insertOne({'name': 'John', 'age': 30});
