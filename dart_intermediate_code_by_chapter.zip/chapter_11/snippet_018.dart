var response = await dio.get('forecast', queryParameters: {
    'latitude': 52.52,
    'longitude': 13.41,
    'hourly': 'temperature_2m'
  });
