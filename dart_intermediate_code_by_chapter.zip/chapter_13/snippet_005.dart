4. Avoid Magic Numbers & Strings
