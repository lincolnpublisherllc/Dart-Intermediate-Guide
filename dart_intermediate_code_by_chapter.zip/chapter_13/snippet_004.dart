void processUserData(Map<String, dynamic> user) {
  _validate(user);
  _saveToDatabase(user);
  _sendWelcomeEmail(user);
}
