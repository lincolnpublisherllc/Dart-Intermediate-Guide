int x = 5; // set x to 5
