// Cache the value to avoid recomputing later
final cachedValue = expensiveComputation();
