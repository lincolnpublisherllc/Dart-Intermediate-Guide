void process(List<int> data) {
  for (var number in data) {
    _printParity(number);
  }
}
