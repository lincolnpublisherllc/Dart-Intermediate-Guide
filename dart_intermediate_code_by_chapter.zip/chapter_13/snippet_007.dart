enum OrderStatus { pending, processing, completed }
if (status == OrderStatus.completed) print('Completed');
