Pin versions in pubspec.yaml when stability is critical.
