class Customer {
  final String name;
  final String email;
  Customer(this.name, this.email);
}
