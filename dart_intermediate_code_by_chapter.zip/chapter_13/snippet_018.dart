void calc(a, b) {
  print(a + b);
  print(a - b);
  print(a * b);
}
