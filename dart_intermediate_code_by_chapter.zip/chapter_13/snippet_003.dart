void processUserData(Map<String, dynamic> user) {
  validate(user);
  saveToDatabase(user);
  sendWelcomeEmail(user);
}
