if (status == 3) print('Completed');
