void process(List<int> data) {
  for (var i in data) {
    if (i % 2 == 0) {
      print('Even: $i');
    } else {
      print('Odd: $i');
    }
  }
}
