Break code into libraries (lib/) and packages. Avoid monolithic files.
