var maxLoginAttempts = 10;
void calculateScores(List<int> scores) {}
