Run dart test automatically.
