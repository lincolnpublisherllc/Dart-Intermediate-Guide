void _printParity(int number) {
  final type = number.isEven ? 'Even' : 'Odd';
  print('$type: $number');
}
