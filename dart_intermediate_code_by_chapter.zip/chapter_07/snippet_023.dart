Spawn an isolate that calculates factorial of a number. Send the result back to the main isolate and print it.
