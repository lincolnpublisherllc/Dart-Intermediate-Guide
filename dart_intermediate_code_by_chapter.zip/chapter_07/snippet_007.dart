Streams: Handling Multiple Asynchronous Values
A Future gives you one result. A Stream gives you a series of results over time (like events, messages, or sensor readings).
Stream<int> countStream(int to) async* {
  for (int i = 1; i <= to; i++) {
    await Future.delayed(Duration(seconds: 1));
    yield i;
  }
}
