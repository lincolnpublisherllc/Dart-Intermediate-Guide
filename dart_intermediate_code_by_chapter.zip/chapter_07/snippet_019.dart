void main() async {
  await Future.wait([
    downloadFile('file1.txt', 2),
    downloadFile('file2.txt', 3),
    downloadFile('file3.txt', 1),
  ]);
  print('All downloads complete.');
}
