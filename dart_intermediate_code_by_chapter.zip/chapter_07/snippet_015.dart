JavaScript: Event loop with async/await, similar to Dart, but no native isolates.
