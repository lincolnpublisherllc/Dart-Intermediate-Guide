Future<void> downloadFile(String name, int seconds) async {
  print('Starting download: $name');
  await Future.delayed(Duration(seconds: seconds));
  print('Finished download: $name');
}
