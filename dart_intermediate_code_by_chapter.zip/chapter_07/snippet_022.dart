Create a stream that emits numbers 1–5 with a 500ms delay. Use await for to print them.
