Simpler concurrency with Future and Stream.
