void main() async {
  print('Fetching order...');
  var order = await fetchUserOrder();
  print('Order ready: $order');
}
