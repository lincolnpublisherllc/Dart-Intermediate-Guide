This uses Future.wait() to run multiple async tasks in parallel and wait until all are finished.
