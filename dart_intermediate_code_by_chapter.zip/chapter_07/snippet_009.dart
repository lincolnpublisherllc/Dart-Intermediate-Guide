Streams are invaluable for UI events (e.g., button clicks), sockets, or real-time data feeds.
