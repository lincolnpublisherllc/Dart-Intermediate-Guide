Example: Spawning an Isolate
import 'dart:isolate';
