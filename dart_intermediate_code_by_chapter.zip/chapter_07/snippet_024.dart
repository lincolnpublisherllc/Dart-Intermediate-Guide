More advanced stream transformations (map, where, asyncMap).
