Notice how the program continues to run while waiting. Without async handling, the app would freeze for 2 seconds.
