Futures and Async/Await
A Future represents a value that will be available later. It’s Dart’s way of modeling asynchronous work.
