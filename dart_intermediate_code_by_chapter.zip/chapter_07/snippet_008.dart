void main() async {
  await for (var value in countStream(3)) {
    print('Received: $value');
  }
}
