void heavyComputation(SendPort sendPort) {
  var sum = 0;
  for (int i = 0; i < 1000000000; i++) {
    sum += i;
  }
  sendPort.send(sum);
}
