Error Handling with Futures
You can use try-catch with await to handle async errors.
Future<void> main() async {
  try {
    var result = await Future.delayed(
      Duration(seconds: 1),
      () => throw Exception('Network failed'),
    );
    print(result);
  } catch (e) {
    print('Caught error: $e');
  }
}
