Write a function that simulates cooking breakfast items (eggs, toast, coffee) asynchronously. Print them in the order they’re finished.
