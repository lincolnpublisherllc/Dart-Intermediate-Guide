void main() {
  var books = [
    Book('1984', 'Orwell'),
    Book('Things Fall Apart', 'Achebe'),
    Book('Brave New World', 'Huxley'),
  ];
