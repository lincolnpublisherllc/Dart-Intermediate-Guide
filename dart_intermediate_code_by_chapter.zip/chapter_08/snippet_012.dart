mixin Swimmer {
  void swim() => print('Swimming...');
}
