void main() {
  var user = User('Ada', 25);
  user.introduce();
}
