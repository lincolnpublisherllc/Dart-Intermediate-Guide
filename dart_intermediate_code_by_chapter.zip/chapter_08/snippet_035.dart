Define a Vehicle class with subclasses Car and Bike.
