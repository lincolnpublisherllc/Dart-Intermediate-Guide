// Borrow all books by Achebe
  var updated = books.map((b) =>
      b.author == 'Achebe' ? b.borrow() : b).toList();
