class Product {
  final String name;
  final double price;
  Product(this.name, this.price);
}
