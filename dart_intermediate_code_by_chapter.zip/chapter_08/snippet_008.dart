void main() {
  var dog = Dog();
  dog.speak();
}
