class MultiFunction implements Printer, Scanner {
