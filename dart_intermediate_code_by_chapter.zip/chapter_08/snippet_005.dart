class Animal {
  void speak() => print('Some sound');
}
