List<int> apply(List<int> numbers, int Function(int) op) {
  return numbers.map(op).toList();
}
