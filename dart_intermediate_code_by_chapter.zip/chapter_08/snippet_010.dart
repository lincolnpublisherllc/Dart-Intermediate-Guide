class Circle implements Shape {
  double radius;
  Circle(this.radius);
