Book(this.title, this.author, {this.isBorrowed = false});
