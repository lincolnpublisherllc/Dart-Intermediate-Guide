void scanData() => print('Multi scan');
}
