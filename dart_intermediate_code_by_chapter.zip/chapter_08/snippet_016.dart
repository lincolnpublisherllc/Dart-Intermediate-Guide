class Scanner {
  void scanData() => print('Scanning...');
}
