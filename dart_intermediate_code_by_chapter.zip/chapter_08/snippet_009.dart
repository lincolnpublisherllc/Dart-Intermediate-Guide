abstract class Shape {
  double area();
}
