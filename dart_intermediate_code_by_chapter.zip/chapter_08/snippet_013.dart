class Fish with Swimmer {}
