void speak() => print('Woof!');
}
