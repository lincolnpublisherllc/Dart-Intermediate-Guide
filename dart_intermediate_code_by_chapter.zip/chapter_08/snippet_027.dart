void main() {
  var products = [
    Product('Shirt', 20),
    Product('Shoes', 50),
    Product('Hat', 15),
  ];
