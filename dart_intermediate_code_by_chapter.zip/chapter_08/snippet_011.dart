double area() => 3.14 * radius * radius;
}
