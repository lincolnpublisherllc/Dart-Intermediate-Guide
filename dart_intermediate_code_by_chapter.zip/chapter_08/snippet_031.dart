Book borrow() => Book(title, author, isBorrowed: true);
}
