void printData() => print('Multi print');
