class Book {
  final String title;
  final String author;
  final bool isBorrowed;
