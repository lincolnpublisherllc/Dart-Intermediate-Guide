final list = [1, 2, 3];
final newList = [...list, 4]; // instead of modifying list
