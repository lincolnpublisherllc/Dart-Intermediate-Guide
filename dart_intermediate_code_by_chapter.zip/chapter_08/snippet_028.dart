var expensive = products.where((p) => p.price > 30).map((p) => p.name);
  print(expensive); // (Shoes)
}
