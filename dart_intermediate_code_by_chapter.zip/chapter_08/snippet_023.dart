void main() {
  print(apply([1, 2, 3], (n) => n * 2)); // [2, 4, 6]
}
