var nums = [1, 2, 3];
var doubled = nums.map((n) => n * 2).toList();
print(doubled); // [2, 4, 6]
