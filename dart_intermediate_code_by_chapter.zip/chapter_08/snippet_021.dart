void main() {
  var f = square;
  print(f(5)); // 25
}
