A class defines a blueprint. An object is an instance of that blueprint.
class User {
  String name;
  int age;
