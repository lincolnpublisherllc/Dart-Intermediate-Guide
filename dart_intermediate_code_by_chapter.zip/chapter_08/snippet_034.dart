updated.forEach((b) {
    print('${b.title} - Borrowed: ${b.isBorrowed}');
  });
}
