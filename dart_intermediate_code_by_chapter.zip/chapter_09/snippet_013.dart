class User {
  final String name;
  final int age;
