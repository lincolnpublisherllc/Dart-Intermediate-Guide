void main() async {
  var dio = Dio();
  var response = await dio.get('https://jsonplaceholder.typicode.com/posts/1');
  print(response.data);
}
