3. Package:json_serializable for Data Models
