GitHub Actions or GitLab CI → run dart test automatically on pushes.
