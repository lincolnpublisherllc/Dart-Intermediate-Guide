void main() async {
  var dio = Dio();
  var logger = Logger();
