class Post {
  final int id;
  final String title;
  Post(this.id, this.title);
