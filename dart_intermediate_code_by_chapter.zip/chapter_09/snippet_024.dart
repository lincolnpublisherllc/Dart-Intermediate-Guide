posts.take(3).forEach((p) => logger.i('Post: ${p.title}'));
}
