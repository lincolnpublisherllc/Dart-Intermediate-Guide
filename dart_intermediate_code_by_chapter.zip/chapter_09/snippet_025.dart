Create a class Product with fields name and price.
Use json_serializable to auto-generate JSON parsing for it.
