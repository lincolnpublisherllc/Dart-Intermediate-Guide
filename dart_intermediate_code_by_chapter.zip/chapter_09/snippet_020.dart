factory Post.fromJson(Map<String, dynamic> json) =>
      Post(json['id'], json['title']);
}
