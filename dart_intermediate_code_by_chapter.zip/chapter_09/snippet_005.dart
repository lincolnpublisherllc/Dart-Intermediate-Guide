void main() {
  var rng = Random();
  print(rng.nextInt(100)); // Random int between 0–99
}
